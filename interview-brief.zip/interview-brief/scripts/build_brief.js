#!/usr/bin/env node
/*
 * build_brief.js — turn an interview-brief content file (JSON) into a Word document.
 *
 * Usage:  node build_brief.js <content.json> <output.docx>
 *
 * What it does for you (so you don't have to get these right by hand):
 *   - Builds the cover page, source-tag key and contents list.
 *   - Numbers sections, STAR stories and interview questions automatically.
 *   - Resolves cross-references: {{sec:id}}, {{q:id}}, {{story:id}}, {{tally}}.
 *   - Computes the requirement tally (Strong / Partial / Gap) from the requirement tables.
 *   - Fails loudly on missing required sections, unresolved references, or bad rating values.
 *   - Prints a JSON summary (sections, questions, stories, [FILL] count, tally, warnings).
 *
 * Inline markup inside any text string:
 *   **bold**   __italic__   [[source tag]]  (rendered grey italic in square brackets)
 *
 * Requires the `docx` npm package (preinstalled in Claude's environment; otherwise `npm install docx`).
 */
const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, AlignmentType, LevelFormat, Footer, PageNumber, BorderStyle,
} = require('docx');

const [, , inPath, outPath] = process.argv;
if (!inPath || !outPath) { console.error('Usage: node build_brief.js <content.json> <output.docx>'); process.exit(1); }
const content = JSON.parse(fs.readFileSync(inPath, 'utf8'));
const meta = content.meta || {};
const sections = content.sections || [];

const REQUIRED = ['objections', 'role', 'requirements', 'company', 'interviewers', 'tmay', 'leaving',
  'star', 'questions', 'ninety', 'ask', 'checklist', 'glossary', 'sources'];
const errors = [], warnings = [];

// ---------- pass 1: numbering ----------
const secNum = {};
sections.forEach((s, i) => { if (!s.id) errors.push(`Section ${i + 1} has no id`); secNum[s.id] = i + 1; });
REQUIRED.forEach(id => { if (!(id in secNum)) errors.push(`Missing required section id "${id}"`); });
const order = sections.map(s => s.id).filter(id => REQUIRED.includes(id));
if (order.join() !== REQUIRED.filter(id => order.includes(id)).join()) warnings.push('Required sections are not in the standard order');

const qNum = {}, storyNum = {};
let qCount = 0, storyCount = 0;
sections.forEach(s => (s.blocks || []).forEach(b => {
  if (b.qa) { qCount++; b.qa._n = qCount; b.qa._sec = secNum[s.id]; if (b.qa.id) qNum[b.qa.id] = { n: qCount, sec: secNum[s.id] }; }
  if (b.star) { storyCount++; b.star._n = storyCount; if (b.star.id) storyNum[b.star.id] = storyCount; }
}));

// ---------- tally from requirement tables ----------
const tally = { Strong: 0, Partial: 0, Gap: 0 };
let reqTables = 0;
sections.forEach(s => (s.blocks || []).forEach(b => {
  if (b.table && b.table.ratingCol !== undefined) {
    reqTables++;
    b.table.rows.forEach((r, i) => {
      const v = String(r[b.table.ratingCol] || '');
      const k = /^Strong/.test(v) ? 'Strong' : /^Partial/.test(v) ? 'Partial' : /^Gap/.test(v) ? 'Gap' : null;
      if (!k) errors.push(`Requirement table row ${i + 1}: rating "${v}" must start with Strong, Partial or Gap`);
      else tally[k]++;
    });
  }
}));
if (!reqTables) errors.push('No requirement table found (a table with "ratingCol" set)');
const tallyText = `${tally.Strong} Strong, ${tally.Partial} Partial, ${tally.Gap} Gap`;

// ---------- reference resolution ----------
function resolve(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/\{\{(\w+)(?::([\w-]+))?\}\}/g, (m, kind, id) => {
    if (kind === 'sec' && secNum[id]) return `section ${secNum[id]}`;
    if (kind === 'q' && qNum[id]) return `section ${qNum[id].sec}, Q${qNum[id].n}`;
    if (kind === 'story' && storyNum[id]) return `Story ${storyNum[id]}`;
    if (kind === 'tally') return tallyText;
    errors.push(`Unresolved reference ${m}`);
    return m;
  });
}
function deepResolve(o) {
  if (typeof o === 'string') return resolve(o);
  if (Array.isArray(o)) return o.map(deepResolve);
  if (o && typeof o === 'object') { const r = {}; for (const k of Object.keys(o)) r[k] = k.startsWith('_') ? o[k] : deepResolve(o[k]); return r; }
  return o;
}
const secs = deepResolve(sections);
const m2 = deepResolve(meta);

// count [FILL]
const fillCount = (JSON.stringify(secs).match(/\[FILL\]/g) || []).length;

if (errors.length) { console.error(JSON.stringify({ ok: false, errors, warnings }, null, 2)); process.exit(2); }

// ---------- styling helpers ----------
const NAVY = '0C1356', BLUE = '2F5FE3', GREY = '6B6B6B';
const W = 9638; // A4 with 2cm margins, in DXA
function runs(text, o = {}) {
  const size = o.size || 21;
  return String(text).split(/(\*\*[^*]+\*\*|\[\[[^\]]+\]\]|__[^_]+__)/).filter(s => s.length).map(s => {
    if (s.startsWith('**')) return new TextRun({ text: s.slice(2, -2), bold: true, size, color: o.color });
    if (s.startsWith('[[')) return new TextRun({ text: '[' + s.slice(2, -2) + ']', italics: true, size: size - 3, color: o.tagColor || GREY });
    if (s.startsWith('__')) return new TextRun({ text: s.slice(2, -2), italics: true, size, color: o.color });
    return new TextRun({ text: s, size, color: o.color, bold: o.bold });
  });
}
const plainHeading = t => String(t).replace(/\[\[([^\]]+)\]\]/g, '($1)').replace(/\*\*|__/g, '');
const P = (t, o = {}) => new Paragraph({ children: runs(t, o), spacing: { after: 120 } });
const H = (t, level, pageBreakBefore = false) => new Paragraph({ heading: level, pageBreakBefore, children: [new TextRun({ text: plainHeading(t) })] });
let listCounter = 0;
const listRefs = [];
function list(items, kind) {
  let ref = kind === 'bullets' ? 'bul' : kind === 'checklist' ? 'chk' : null;
  if (kind === 'numbered') { ref = `num${listCounter++}`; listRefs.push(ref); }
  return items.map(t => new Paragraph({ numbering: { reference: ref, level: 0 }, children: runs(t), spacing: { after: 60 } }));
}
const border = { style: BorderStyle.SINGLE, size: 4, color: 'BFBFBF' };
const borders = { top: border, bottom: border, left: border, right: border };
function cell(content, width, o = {}) {
  return new TableCell({
    borders, width: { size: width, type: WidthType.DXA },
    shading: o.fill ? { fill: o.fill, type: ShadingType.CLEAR, color: 'auto' } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: (Array.isArray(content) ? content : [content]).map(t =>
      new Paragraph({ children: runs(t, { size: 18, bold: o.bold, color: o.color, tagColor: o.tagColor }), spacing: { after: 40 } })),
  });
}
function scaleWidths(rel, n) {
  const r = rel && rel.length === n ? rel : Array(n).fill(1);
  const sum = r.reduce((a, x) => a + x, 0);
  const w = r.map(x => Math.floor(W * x / sum));
  w[w.length - 1] += W - w.reduce((a, x) => a + x, 0);
  return w;
}
function table(t) {
  const n = t.header.length;
  const widths = scaleWidths(t.widths, n);
  const hdr = new TableRow({ tableHeader: true, children: t.header.map((h, i) => cell(h, widths[i], { fill: NAVY, bold: true, color: 'FFFFFF', tagColor: 'C9D3F5' })) });
  const rows = t.rows.map(r => new TableRow({ cantSplit: true, children: Array.from({ length: n }, (_, i) => {
    const c = r[i] ?? '';
    let fill;
    if (t.ratingCol === i) fill = /^Strong/.test(c) ? 'E2F0D9' : /^Gap/.test(c) ? 'F8D7DA' : 'FFF2CC';
    if (t.firstBold && i === 0) return cell(c, widths[i], { bold: true, fill: 'F2F4FA' });
    return cell(c, widths[i], { fill });
  }) }));
  return [new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: widths, rows: [hdr, ...rows] }), new Paragraph({ children: [], spacing: { after: 80 } })];
}
function callout(lines) {
  const side = { style: BorderStyle.SINGLE, size: 4, color: BLUE };
  return [new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: [W],
    rows: [new TableRow({ children: [new TableCell({
      borders: { top: side, bottom: side, right: side, left: { style: BorderStyle.SINGLE, size: 24, color: BLUE } },
      width: { size: W, type: WidthType.DXA }, shading: { fill: 'EEF2FD', type: ShadingType.CLEAR, color: 'auto' },
      margins: { top: 100, bottom: 100, left: 160, right: 160 },
      children: lines.map(t => new Paragraph({ children: runs(t, { size: 20 }), spacing: { after: 60 } })),
    })] })],
  }), new Paragraph({ children: [], spacing: { after: 80 } })];
}
function star(s) {
  const w1 = 1500, w2 = W - 1500;
  const row = (k, v) => new TableRow({ children: [cell(k, w1, { bold: true, fill: 'F2F4FA' }), cell(v, w2)] });
  const rows = [['Situation', s.situation], ['Task', s.task], ['Action', s.action], ['Result', s.result], ['Use it for', s.useFor]];
  if (s.fill) rows.push(['Fill in', s.fill]);
  return [H(`Story ${s._n} — ${s.title}`, HeadingLevel.HEADING_2),
    new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: [w1, w2], rows: rows.map(([k, v]) => row(k, v)) }),
    new Paragraph({ children: [], spacing: { after: 80 } })];
}
function qa(q) {
  const out = [H(`Q${q._n}. ${q.q}`, HeadingLevel.HEADING_3)];
  (Array.isArray(q.a) ? q.a : [q.a]).forEach(t => out.push(P(t)));
  if (q.watch) out.push(P('**Watch out:** ' + q.watch, { color: '7A4B00' }));
  return out;
}
function block(b) {
  if (b.p !== undefined) return [P(b.p)];
  if (b.h !== undefined) return [H(b.h, HeadingLevel.HEADING_2)];
  if (b.h3 !== undefined) return [H(b.h3, HeadingLevel.HEADING_3)];
  if (b.bullets) return list(b.bullets, 'bullets');
  if (b.numbered) return list(b.numbered, 'numbered');
  if (b.checklist) return list(b.checklist, 'checklist');
  if (b.table) return table(b.table);
  if (b.callout) return callout(b.callout);
  if (b.star) return star(b.star);
  if (b.qa) return qa(b.qa);
  warnings.push('Unknown block type: ' + Object.keys(b).join(','));
  return [];
}

// ---------- cover ----------
const children = [
  new Paragraph({ children: [new TextRun({ text: 'INTERVIEW BRIEF', bold: true, size: 22, color: BLUE })], spacing: { before: 1800, after: 120 } }),
  new Paragraph({ children: [new TextRun({ text: m2.role || 'Role', bold: true, size: 52, color: NAVY })], spacing: { after: 80 } }),
  new Paragraph({ children: [new TextRun({ text: m2.subtitle || m2.company || '', size: 28, color: NAVY })], spacing: { after: 80 } }),
  new Paragraph({ children: [new TextRun({ text: [m2.reference, m2.candidate && `Prepared for ${m2.candidate}`, m2.date].filter(Boolean).join(' · '), size: 22, color: GREY })], spacing: { after: 80 } }),
  new Paragraph({ children: [new TextRun({ text: `Built from: ${m2.cv_version || 'CV version not stated'}${m2.partial_spec ? ' · PARTIAL SPEC — see section 1' : ''}`, size: 20, color: GREY })], spacing: { after: 500 } }),
  H('How to read this brief', HeadingLevel.HEADING_2),
  P('Every claim carries a source tag so you can see where it came from and how far to trust it:'),
  ...table({ widths: [2, 7], header: ['Tag', 'Meaning'], firstBold: true, rows: [
    ['[[JD]]', 'The job description you supplied.'],
    ['[[CV]]', `Your CV (${m2.cv_version || 'version as supplied'}).`],
    ['[[You told me]]', 'Something you told me that is not on the CV.'],
    ['[[Web: source]]', `Retrieved by web search${m2.date ? ' on ' + m2.date : ''}. Full list in the Sources appendix.`],
    ['[[My knowledge]]', 'My general knowledge, not checked for this brief. Verify before relying on it.'],
    ['[[Inference]] / [[Guess]]', 'My reasoning from the evidence. A hypothesis to test, not a fact.'],
  ] }),
  P('**Contents:** ' + secs.map((s, i) => `${i + 1} ${plainHeading(s.title)}`).join(' · ')),
  P('Wherever you see **[FILL]**, the brief needs a real detail from you that I do not have. Do not walk into the interview with those blank.'),
];
secs.forEach((s, i) => {
  children.push(H(`${i + 1}. ${s.title}`, HeadingLevel.HEADING_1, true));
  (s.blocks || []).forEach(b => children.push(...block(b)));
});

// ---------- document ----------
const numConfig = [
  { reference: 'bul', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] },
  { reference: 'chk', levels: [{ level: 0, format: LevelFormat.BULLET, text: '☐', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 320 } } } }] },
  ...listRefs.map(r => ({ reference: r, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 320 } } } }] })),
];
const doc = new Document({
  creator: 'Claude', title: `Interview Brief — ${m2.role || ''}`,
  styles: {
    default: { document: { run: { font: 'Arial', size: 21 } } },
    paragraphStyles: [
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 34, bold: true, font: 'Arial', color: NAVY },
        paragraph: { spacing: { before: 120, after: 200 }, outlineLevel: 0, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: BLUE, space: 4 } } } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 26, bold: true, font: 'Arial', color: BLUE }, paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } },
      { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 22, bold: true, font: 'Arial', color: NAVY }, paragraph: { spacing: { before: 200, after: 80 }, outlineLevel: 2 } },
    ],
  },
  numbering: { config: numConfig },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1134, bottom: 1134, left: 1134, right: 1134 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [
      new TextRun({ text: `${m2.footer || m2.role || 'Interview brief'} · Page `, size: 16, color: GREY }),
      new TextRun({ children: [PageNumber.CURRENT], size: 16, color: GREY })] })] }) },
    children,
  }],
});

if (storyCount < 4 || storyCount > 6) warnings.push(`STAR stories: ${storyCount} (target 4–6)`);
if (qCount < 12) warnings.push(`Likely questions: ${qCount} (target 12+)`);

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(outPath, buf);
  console.log(JSON.stringify({ ok: true, output: outPath, sections: secs.length, questions: qCount, stories: storyCount,
    fill_markers: fillCount, requirement_tally: tallyText, warnings }, null, 2));
});
