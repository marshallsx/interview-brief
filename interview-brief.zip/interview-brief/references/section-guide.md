# Section guide

What each section of the brief must contain, and why. Section ids in brackets are the ids the build script expects, in this order.

## Contents
1. Read this first: the strongest objections (`objections`)
2. Role summary (`role`)
3. Every requirement mapped to your evidence (`requirements`)
4. Company research (`company`)
5. Interviewer profiles (`interviewers`)
6. "Tell me about yourself" — 90 seconds (`tmay`)
7. Why you are leaving (`leaving`)
8. STAR stories (`star`)
9. Likely questions and model answers (`questions`)
10. First 90 days (`ninety`)
11. Questions to ask them (`ask`)
12. Prep checklist (`checklist`)
13. Appendix A — Glossary (`glossary`)
14. Appendix B — Sources (`sources`)

---

## 1. Read this first (`objections`)

The candidate's standing rule is objections before endorsement. This page tells them what could sink the application, before anything encouraging.

Cover each of these that applies, as a short H2 with two or three bullets:
- **Level and pay fit.** Compare the title, grade and duties with the candidate's current level and pay (if known from memory). Use any advertised band, the same company's bands for similar roles elsewhere, and market data. State plainly whether the role probably pays above or below current pay, and label that as a guess unless the band is published.
- **The weakest headline requirement.** Usually the first or most specific bullet of the spec. Quote it (short), state the candidate's evidence, and say plainly if it falls short.
- **Domain gaps.** Any sector knowledge the spec asks for that the CV doesn't show.
- **CV points an interviewer may probe.** Overlapping dates, vague employment types (e.g. "engaged" for unpaid work), qualifications held but not on the CV, gaps in dates. Give the fix or the honest line to use.
- **Advert age and status.** Read the posting date carefully — US employers write MM/DD/YYYY. Work out the age of the advert. A low requisition number relative to other recent postings suggests a re-post. Label as inference.
- **Partial spec** (if only a recruiter summary was given): list what the full spec would need to answer.

End with a callout: one-line **case against applying** and one-line **case for**, then "the call is yours". Do not recommend either way unless asked.

## 2. Role summary (`role`)

- A two-column fact table: title, team, location (and office address if found), reference, posting date (with the date-format reading), level, category, line of business (decode abbreviations, label guesses), reporting line if given, degree and certification asks, special conditions (securities disclosure, vetting, travel).
- **What the job actually is, in plain words**: one paragraph translating the spec into daily reality. Name who the users or clients probably are, with the evidence.
- **What they will test**: three to five numbered points.
- **Where you stand out**: three bullets, each with evidence.

## 3. Requirements map (`requirements`)

This is the core of the brief. Every requirement line in the job description gets a row — count the lines in the spec and count the rows; they must match. Split into sub-tables: skills/competencies, education/certifications, responsibilities, and values if the spec states any.

Columns: Requirement [[JD]] · Your evidence · Rating · Gap and honest mitigation. Set `ratingCol` to the rating column index so the script colours the cells and computes the tally.

Rating rules:
- **Strong** — evidenced on the CV with numbers or specifics.
- **Partial** — real but thinner than asked, or the candidate has told you about it but it's not on the CV.
- **Gap** — not evidenced. Mitigation only. Never soften a Gap into a Partial to make the page look better.

Mitigation rules:
- Say what the candidate should actually say, in quotes where useful.
- Where evidence probably exists but isn't on file, write **[FILL]** with what's needed.
- Point to the relevant question in section 9 with `{{q:id}}`.

End the section with: `**Tally:** {{tally}}` plus one sentence on what the Partials mostly are.

## 4. Company research (`company`)

Sub-headings (H2), each a bullet list, every bullet tagged with its source:
- **At a glance** — what the company does, business units, size, latest results (most recent quarter), leaders relevant to the role.
- **Strategy relevant to the role** — e.g. AI strategy for an AI role, transformation programme for a transformation role.
- **Where this job sits** — what the team does, who uses its output, any public statement that reveals the business case. Mark implications as [[Inference]].
- **Regulation** — if the employer is regulated, who regulates it and any recent regulator publications. This is often where the candidate's background connects.
- **Competitors** — two or three names.
- **A hook to the candidate's background** — one, used lightly.

Paraphrase everything. At most one short quotation per source, under 15 words.

## 5. Interviewer profiles (`interviewers`)

If names were supplied: one H2 per person with title, background (from LinkedIn or public bios found by search), what they will likely care about, and the candidate's best angle. Only use public professional information. Do not speculate about personal matters.

If no names were supplied, say so in bold at the top, then give:
- a **likely panel shape** table (interviewer type · what they care about · lead with) — label (my guess),
- senior names the candidate may hear about,
- a blank table to fill once names arrive.

## 6. Tell me about yourself (`tmay`)

About 220 words (90 seconds at speaking pace), in a callout. Built only from CV facts. Shape:
1. One-line identity tied to what this role values.
2. Career arc in three or four sentences with two or three memorable numbers.
3. The most relevant recent work, stated honestly.
4. The thread that ties it together.
5. Why this role — one sentence, specific to the employer.

Follow it with a short "why this shape" note.

## 7. Why you are leaving (`leaving`)

- **What is true** — the facts from memory or the user, briefly.
- **What to leave out** — anything true but unhelpful: disputes, pay-off or settlement motives, pension or legal claims, health, grievances, criticism of the current employer. These appear only here, never in a model answer.
- **Model answer** — about 30 seconds, in a callout. Factual, positive, forward-looking. Add "Check each clause is true before you use it."
- **Follow-ups** — likely probes (why not stay, why this level, date overlaps) as Q&A blocks without numbering prefixes — use `h3` + `p` rather than `qa` so they don't consume question numbers.

If you have no information on why they are leaving, write the section as questions to the user plus a generic template, and add a [FILL].

## 8. STAR stories (`star`)

Four to six stories. Each uses a `star` block with id, title (lead with the number), useFor, situation, task, action, result, fill.

Rules:
- Every number comes from the CV or from something the user told you. Tag if not CV.
- Actions go only as far as the CV describes. The `fill` field names the one or two vivid details the candidate must add — a specific risk, a decision, a problem hit.
- Choose stories to cover the spec's weightings: delivery under pressure, stakeholders, technical depth, governance/quality, change/adoption, commercial/finance.
- `useFor` must name the requirement rows or questions the story answers.

Close with "Backup numbers" — other CV numbers worth having ready.

## 9. Likely questions and model answers (`questions`)

At least 12, usually 15–20. Draw from references/question-bank.md for the role type, plus questions generated from each Gap and Partial in the map. Each is a `qa` block with an id so other sections can reference it.

Answers:
- Short — three to six sentences. Say the answer, then stop.
- In the candidate's voice, in quotes.
- Where the answer needs a real example the brief doesn't have, give the structure and a [FILL] rather than inventing one.
- Use `watch` for traps: inflation risk, facts to verify, disclosures to think about (e.g. current salary).
- Define any technical term inside the answer or in the glossary.

## 10. First 90 days (`ninety`)

Principle line, then three H2 phases (Days 1–30 Learn, 31–60 Stabilise, 61–90 Improve — or phases that fit the role), each a `checklist` of items a manager could verify. Tie items to the role's stated responsibilities.

## 11. Questions to ask them (`ask`)

Three groups, each a numbered list: about the work; about context and success; for the recruiter or HR (grade, band, process, hybrid pattern, new or backfill). 12–16 questions total. At least two must use the company research (show homework).

## 12. Prep checklist (`checklist`)

A checklist of concrete tasks before the day: questions for the recruiter, CV fixes, every [FILL], reading from section 4 with specific documents named, hands-on refreshers for any tool gaps, disclosures to check, rehearsal.

## Appendix A — Glossary (`glossary`)

Two-column table of every technical, domain or employer-specific term used in the brief, in plain English. Tag the intro [[My knowledge]].

## Appendix B — Sources (`sources`)

- Documents supplied (JD, CV with version, memory/earlier conversations — list what was used).
- Web sources with publisher, title and date.
- **Not checked** — everything relevant you could not verify. Never leave this empty; there is always something.
