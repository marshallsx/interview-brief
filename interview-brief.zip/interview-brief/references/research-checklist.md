# Research checklist

Run these before writing. Search each item separately — combined queries return shallow results. Typical total: 6–12 searches. Record every source you use for Appendix B.

## From the advert itself (no search needed)
- [ ] Posting date — which format? Check another posting on the same careers site to confirm MM/DD vs DD/MM. Work out the advert's age from today's date.
- [ ] Reference / requisition number — compare with other postings on the same site if they appear in results; a low number with a recent date suggests a re-post.
- [ ] Decode abbreviations (business unit codes, grade names). Label guesses.
- [ ] Any salary band, grade, hybrid pattern, security or disclosure conditions.

## Company
- [ ] Latest quarterly or annual results: revenue, growth, the business unit this role sits in.
- [ ] Strategy statements relevant to the role (earnings calls, investor days, press releases) from the last 6–12 months.
- [ ] Anything public about the specific team or function (team pages, blog posts, conference talks, job adverts for sibling roles).
- [ ] Leaders: CEO, the head of the relevant division. Confirm they are current — search, don't recall.
- [ ] Recent news (last 3 months): acquisitions, divestments, restructures, partnerships, layoffs.
- [ ] Stated values or principles (e.g. responsible AI principles for an AI role).
- [ ] Main competitors.

## Regulation (if the employer is regulated)
- [ ] Who regulates it in the UK (and US/EU if relevant).
- [ ] Recent regulator publications about this sector: reviews, Dear CEO letters, enforcement. These tell you what the regulator will ask about any change the role delivers.

## Pay
- [ ] Advertised band for this role, if any.
- [ ] The same employer's advertised bands for similar roles (US postings often publish ranges).
- [ ] Market data for the title and location (Robert Half, Levels.fyi, Glassdoor, Hays).
- [ ] Compare against the candidate's current pay if known from memory; label the comparison a guess unless the band is published.

## Interviewers (only if names supplied)
- [ ] Current title and tenure, career background, public talks or articles. Professional information only.

## Candidate context (from memory, not search)
- [ ] Why they are leaving; current salary; related applications and briefs already done; qualifications passed but missing from the CV; standing constraints such as clients that cannot be named.

## Rules
- Believe recent search results over recalled knowledge for anything current (roles, results, leaders).
- Be sceptical of low-quality aggregator sites; prefer company IR pages, regulators and established financial press.
- Paraphrase. At most one short quote per source, under 15 words.
- If a search finds nothing, say so in the brief rather than filling the gap from memory.
