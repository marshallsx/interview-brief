# Question bank

Pick the universal set plus the set(s) matching the role. Then add one question per Gap and major Partial in the requirements map — those are the questions most likely to be asked and least likely to be prepared for. Write model answers from the candidate's CV; never invent examples — use [FILL].

## Universal (always include)
- Why this company, and why this role?
- Walk me through your experience of [the spec's headline requirement].
- Tell me about a difficult senior stakeholder.
- Tell me about a time something went wrong. (Structure: stopped, said so early, re-planned; what changed afterwards.)
- What are your salary expectations? (Watch: whether to disclose current pay is the candidate's choice.)
- Level-fit question if the role is above or below the candidate's current level ("Why a step down/up?").
- Why are you leaving? (covered in the leaving section; don't duplicate)

## Delivery / project / programme manager
- How do you manage dependencies across teams, including external suppliers?
- How would you run quarterly or PI planning?
- How do you estimate uncertain work? (story points, velocity, burndown, spikes — and their limits)
- Scrum or Kanban — when would you use each?
- How would you coach a team that is sceptical of agile?
- What would you put on a delivery dashboard? What OKRs would you set?
- How do you identify and handle delivery risk early?
- How do you track quality and drive continuous improvement?
- How would you run a pilot and decide whether to scale it?

## AI / ML / data delivery
- How is delivering ML or GenAI different from normal software delivery?
- How would you run agile for a data science team?
- How would you make sure an AI tool is robust, secure and trustworthy (in this employer's regulatory context)?
- What's your hands-on technical depth? Data science workflows, cloud platform named in the spec?
- Explain [a technique on the CV, e.g. RAG] simply.
- How do you use AI in your own work?
- How would you measure the value of an AI deployment? (adoption, time saved, quality, cost)

## Transformation / director / head-of
- How would you build an AI (or transformation) strategy here from scratch?
- How do you build a business case and prove benefits afterwards?
- How do you get a sceptical executive team to fund something?
- How do you design an operating model / governance for this capability?
- Tell me about a team you built. How did you hire and develop people?
- What would you stop doing in your first 90 days?
- How do you handle a failing programme you inherit?

## Consulting / business development
- How have you originated work? Walk me through a deal from idea to signature.
- How would you grow an account?
- Tell me about a proposition you built and took to market.
- How do you handle a client who wants something that isn't in their interest?
- What's your view on [sector trend]? (thought-leadership probe)

## Product
- How do you decide what goes in the backlog and in what order?
- How do you measure product value?
- Tell me about a feature you killed.
- How do you collect and act on user feedback?

## Domain / sector (build from the company research)
- What do you know about how [the employer's core product/process] works? (e.g. how a credit rating is produced)
- What do you think are the biggest risks or regulatory pressures in this sector right now?
- How would your experience in [candidate's sector] transfer here?
Mark any domain explanation built from general knowledge as [[My knowledge]] and tell the candidate to verify it on the employer's own site.
