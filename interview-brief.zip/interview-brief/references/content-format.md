# Content file format

The build script reads one JSON file. A worked example is in `assets/example-content.json` — copy its shape. It is abbreviated to show the format; a real brief should meet the targets in `section-guide.md` (full requirement map, 15–20 questions, full research).

## Top level
```json
{
  "meta": {
    "role": "Automation Lead",
    "company": "Harbour & Lane Insurance (fictional)",
    "subtitle": "Harbour & Lane Insurance · Claims Operations · Leeds",
    "reference": "Job reference HL-0421",
    "candidate": "Alex Morgan",
    "date": "1 October 2026",
    "cv_version": "CV_AlexMorgan_v3.docx",
    "partial_spec": false,
    "footer": "Harbour & Lane Automation Lead · Interview brief (fictional example)"
  },
  "sections": [ { "id": "objections", "title": "Read this first: the strongest objections", "blocks": [ ... ] } ]
}
```
Section titles are written without numbers — the script adds them. Required ids, in order: `objections, role, requirements, company, interviewers, tmay, leaving, star, questions, ninety, ask, checklist, glossary, sources`.

## Blocks
| Block | Shape | Notes |
|---|---|---|
| Paragraph | `{"p": "text"}` | |
| Sub-heading | `{"h": "text"}` / `{"h3": "text"}` | Source tags in headings become "(tag)". |
| Bullets | `{"bullets": ["a", "b"]}` | |
| Numbered | `{"numbered": ["a", "b"]}` | Each list restarts at 1. |
| Checklist | `{"checklist": ["a", "b"]}` | Rendered with ☐ boxes. |
| Table | `{"table": {"widths": [2,3,1,3], "header": [...], "rows": [[...]], "ratingCol": 2, "firstBold": true}}` | `widths` are relative. `ratingCol` marks a requirement table: values must start Strong / Partial / Gap; they are coloured and counted. |
| Callout | `{"callout": ["line", "line"]}` | Shaded box — use for the 90-second answer, model "why leaving" answer, and case for/against. |
| STAR story | `{"star": {"id", "title", "useFor", "situation", "task", "action", "result", "fill"}}` | Auto-titled "Story n — title". |
| Question | `{"qa": {"id", "q", "a": "text" or ["para", "para"], "watch": "optional trap"}}` | Auto-numbered "Qn." across the brief. |

## Inline markup (any text)
- `**bold**`, `__italic__`
- `[[JD]]`, `[[CV]]`, `[[You told me]]`, `[[Web: Publisher]]`, `[[My knowledge]]`, `[[Inference]]`, `[[Guess]]` — grey source tags
- `[FILL]` — a detail the candidate must add (write it bold: `**[FILL]**`); the script counts them

## Cross-references (resolved by the script — never type numbers by hand)
- `{{sec:company}}` → "section 4"
- `{{q:scale}}` → "section 9, Q3" (needs a `qa` block with that id)
- `{{story:returns}}` → "Story 1"
- `{{tally}}` → "15 Strong, 11 Partial, 1 Gap", computed from all requirement tables

Unresolved references, missing required sections or bad rating values stop the build with an error list.

## Writing JSON safely
Use typographic apostrophes (’) and quotes (“ ”) inside text to avoid escaping problems. Write the file with the create_file tool, then run:
```
node scripts/build_brief.js content.json /mnt/user-data/outputs/Interview_Brief_<Company>_<Role>.docx
```
