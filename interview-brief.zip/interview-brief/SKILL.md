---
name: interview-brief
description: "Build a full interview brief as a Word document from a job description plus the CV the candidate sent to that employer: strongest objections first, every requirement mapped to CV evidence with honest gaps, sourced company research, interviewer profiles, a 90-second \"tell me about yourself\", a why-leaving answer, STAR stories built from real CV numbers, likely questions with model answers, a first-90-days plan and questions to ask. Use whenever the user shares a job spec, job advert, screenshots of a posting or a recruiter's role description and wants interview preparation: \"prepare an interview brief\", \"prep me for this interview\", \"I've got an interview with X\", \"help me get ready for this role\", even if they never say \"brief\". Not for cover letters, CV rewrites or short recruiter-call prep on their own."
---

# Interview Brief

Produce a private, honest preparation document the candidate reads before an interview. Its job is to stop them being surprised in the room: by a gap, a CV inconsistency, a question they hadn't prepared for, or a fact about the company they should have known.

Three principles drive everything below:
- **Honesty over encouragement.** Objections come first. Gaps are called gaps. A brief that flatters sends the candidate in unprepared for exactly the probes that lose offers.
- **Every claim has a source.** The candidate must be able to tell a fact from the CV, a web finding, your general knowledge and your guess, because in the room they can only defend the first two.
- **Never invent experience.** Interviewers probe specifics. An invented detail the candidate repeats is worse than a gap. Where a real detail is needed and you don't have it, write **[FILL]** and say what's needed.

Write in plain English and define every technical term the first time it's used (and in the glossary). The deliverable is a Word document; chat replies stay short.

**No em-dashes anywhere in the deliverable.** Recast instead: a comma for an aside, a colon where the second half explains the first, a semicolon for two linked clauses, brackets for a parenthesis, or a full stop and a new sentence. A spaced hyphen standing in for an em-dash is the same mistake. En-dashes in number and date ranges are fine. Note that `scripts/build_brief.js` inserts em-dashes of its own, in the story titles and the cover's PARTIAL SPEC line; step 4 says how to deal with that.

---

## Step 0: Check the inputs before doing anything else

Check all four, then ask for everything missing **in one message** and stop until the blocking items arrive.

1. **Job description, blocking.** Accept pasted text, screenshots, a URL (fetch it) or a recruiter's message. If there is nothing, ask for it and stop. If all you have is a recruiter's summary rather than a full spec, you may proceed, but set `partial_spec: true`, say so on the objections page, and list what to ask the recruiter. A full role description that still omits reference, posting date, pay, location and contract terms counts as partial too: say so and list them.
2. **CV, blocking.** If no CV is attached, ask for it and stop. Also ask **which CV version was sent to this employer**, unless the user has already said: the interviewer is reading that version, so the brief must quote from it. Do not substitute memory or an earlier CV on your own. If the user explicitly says to use a CV you already have, name the version on the cover (`cv_version`).
3. **Interviewer names, not blocking.** Ask once. If there are none, build the likely-panel version of section 5.
4. **Interview type.** This skill is for full interviews. If the user is really preparing for a short recruiter call, say so and offer a shortened brief instead.

Ask the stage (first, second, final) and whether the role is permanent or contract in the same message. Both change the pay section and the question set; for a contract, research day rates and IR35 status rather than salary, and cost the comparison against the candidate's current package rather than the headline number.

Memory and earlier conversations are still useful context: why they're leaving, current pay, qualifications passed but missing from the CV, clients that cannot be named, other applications. Use them, tagged `[[You told me]]`. They supplement the CV; they never replace it.

## Step 1: Read and extract

- **From the JD:** list every requirement line, grouped (skills, education/certifications, responsibilities, values, conditions). Count them; every one must appear in the requirements map. Requirements stated in the spec's narrative paragraphs count as well as those in the bulleted list.
- **From the CV:** every fact with a number (money, people, customers, durations, percentages, before/after times), every qualification, dates of each role.
- **Cross-check:** overlapping or unexplained dates, wording that overstates (e.g. "engaged" for unpaid work), totals that don't reconcile with the dates listed (a claimed career length the earliest role doesn't support, or a sector claim the early roles don't fit), qualifications you know of that aren't on the CV. These go on the objections page.

## Step 2: Research

Read `references/research-checklist.md` and work through it. Search each item separately; typically 6 to 12 searches. Keep a running source list for Appendix B. If something can't be found, record it under "Not checked" rather than filling it from memory.

Where the employer is itself assessed, audited or rated by a regulator or a client, find the most recent assessment and read it properly, annexes included. It tells you what the employer is under pressure to fix, which is usually why the role is open and almost always what the candidate's best answers should speak to.

## Step 3: Write the content

Read `references/section-guide.md`: it defines the 14 sections, their order and what each must contain. Read `references/question-bank.md` for section 9.

Write the brief as a JSON content file in the format described in `references/content-format.md` (copy the shape of `assets/example-content.json`). Key conventions:
- Tag every factual claim: `[[JD]] [[CV]] [[You told me]] [[Web: Publisher]] [[My knowledge]] [[Inference]] [[Guess]]`.
- Use `{{q:id}}`, `{{sec:id}}`, `{{story:id}}` and `{{tally}}` for cross-references, never section or question numbers typed by hand. The script resolves them, so they can't drift when sections change.
- Sensitive personal circumstances (disputes, settlement or pension claims, health, grievances) appear only under "What to leave out" in section 7, never in a model answer.
- If the user has said a client or employer cannot be named, never name it anywhere.
- Paraphrase web sources; at most one short quote per source, under 15 words.

Extra sections beyond the 14 are allowed, and the script accepts them as long as all 14 required ids are present and in order. Add one when the user asks for something the standard sections don't carry, or when the role turns on a programme, product or domain the candidate must be able to explain cold. Give it its own id and place it where it reads best.

## Step 4: Build the Word document

The build script inserts em-dashes of its own, so work from a patched copy:

```
cp <skill-path>/scripts/build_brief.js ./build_brief_local.js
```

In the copy, replace the em-dash in the `Story ${s._n} — ${s.title}` heading, in the `PARTIAL SPEC — see section 1` cover line, and in the document `title` property. Then:

```
node ./build_brief_local.js content.json /mnt/user-data/outputs/Interview_Brief_<Company>_<Role>.docx
```

The script adds the cover, source-tag key and contents list; numbers sections, stories and questions; computes the requirement tally; and prints a summary. If it exits with errors (missing section, unresolved reference, rating value not starting Strong/Partial/Gap), fix the JSON and rerun. Read any warnings (e.g. fewer than 4 stories or 12 questions) and fix them unless there is a good reason.

## Step 5: Verify before calling it done

1. Render and look at every page:
   ```
   python /mnt/skills/public/docx/scripts/office/soffice.py --headless --convert-to pdf <file>.docx
   pdftoppm -jpeg -r 60 <file>.pdf page
   ```
   Check tables fit, no raw markup (`**`, `[[`, `{{`) is visible, headings read correctly.
2. Extract the text and search it for **em-dashes and raw markup**. Do not report either as checked until the search has been run and returned nothing.
   ```
   pdftotext <file>.pdf out.txt && grep -c "—" out.txt
   ```
3. Tick the user's requested sections against the draft. If they asked for sections beyond the standard 14, confirm they are there.
4. Confirm the requirement-map row count equals the JD requirement count from Step 1.
5. Confirm every number in sections 6 and 8 appears in the CV or is tagged `[[You told me]]`.
6. List what you did **not** check. This goes in Appendix B and in the chat reply.

## Step 6: Deliver

Present the file. Keep the chat reply short:
- the two or three strongest objections, in a sentence each;
- the most useful research angle found;
- the requirements checklist, ticked;
- what was not checked;
- the number of [FILL] markers and the three most important to complete.

Do not repeat the brief's content in chat.